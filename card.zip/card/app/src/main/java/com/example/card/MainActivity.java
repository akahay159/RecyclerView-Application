package com.example.card;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView rcv;
    MyAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("RecyclerView");
        rcv = findViewById(R.id.recview);
         rcv.setLayoutManager(new LinearLayoutManager(this)); // to show it in vertical layout
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this,
//                LinearLayoutManager.HORIZONTAL,false); // to show it to horizontal layout
//        rcv.setLayoutManager(layoutManager);
        //GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2);
        //rcv.setLayoutManager(gridLayoutManager); // for grid layout for this user has to change the xml file according to their requirements
        adapter = new MyAdapter(dataqueue(),getApplicationContext());
        rcv.setAdapter(adapter);

    }
    public ArrayList<Model> dataqueue(){
        ArrayList<Model> holder = new ArrayList<>();
        Model ob1 = new Model();
        ob1.setHeader("VIRAT");
        ob1.setDesc("CAPTAIN");
        ob1.setImgname(R.drawable.ic_launcher_background);
        holder.add(ob1);

        Model ob2 = new Model();
        ob2.setHeader("ROHIT");
        ob2.setDesc("BATSMAN");
        holder.add(ob2);

        Model ob3 = new Model();
        ob3.setHeader("DHAWAN");
        ob3.setDesc("BATSMAN");
        holder.add(ob3);

        Model ob4 = new Model();
        ob4.setHeader("RAHUL");
        ob4.setDesc("BATSMAN + WICKTKEEPER");
        holder.add(ob4);

        Model ob5 = new Model();
        ob5.setHeader("SHREYAS");
        ob5.setDesc("BATSMAN");
        holder.add(ob5);

        Model ob6 = new Model();
        ob6.setHeader("HARDIK");
        ob6.setDesc("ALLROUNDER");
        holder.add(ob6);

        Model ob7 = new Model();
        ob7.setHeader("JADEJA");
        ob7.setDesc("ALLROUNDER");
        holder.add(ob7);

        Model ob8 = new Model();
        ob8.setHeader("CHAHAL");
        ob8.setDesc("BOWLER");
        holder.add(ob8);

        Model ob9 = new Model();
        ob9.setHeader("BUMBRAH");
        ob9.setDesc("BLOWER");
        holder.add(ob9);

        Model ob10 = new Model();
        ob10.setHeader("SHAMI");
        ob10.setDesc("BOLWER");
        holder.add(ob10);

        Model ob11 = new Model();
        ob11.setHeader("NATRAJAN");
        ob11.setDesc("BOWLER");
        holder.add(ob11);

        Model ob12 = new Model();
        ob12.setHeader("PANT");
        ob12.setDesc("BATSMAN+WICKETKEEPER");
        holder.add(ob12);

        return holder;
    }
}